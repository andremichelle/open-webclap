# Aether for WebCLAP

Aether by sletz, a hybrid polyphonic synthesizer written in Faust (subtractive, four-operator FM and additive
engines, a modulation matrix, a 16-step sequencer and a stereo effects bus), ported to WebCLAP. This is not an
official faust-aether release.

- faust-aether: https://github.com/sletz/faust-aether (commit 28f262c1de87ae9fae424be7ee22bcbf665cd7bd)
- This port, and the complete source of this bundle: https://github.com/synth-is/open-webclap/tree/fb62d894c91062bbe59b2e65e295e9e34875de7e (plus uncommitted changes: not a release build)
  Build it with `scripts/build-faust-aether.sh`, which fetches every dependency below at the commit named here and
  runs the pinned Faust compiler (2.88.0) on upstream's `aether.dsp` / `effects.dsp` (`ports/faust-aether/gen.py`).

## License

The bundle is licensed under the **MIT License** (`LICENSE`, faust-aether's). The bundle contains no JUCE.

## Components

| Component | Copyright | License |
|---|---|---|
| [faust-aether](https://github.com/sletz/faust-aether) (`aether.dsp`, `effects.dsp`, and the presets the page ships as `ui/patches.json`) | 2026 Stéphane Letz | MIT |
| The C++ the Faust compiler 2.88.0 generates from those sources, embedding the Faust standard libraries | 2002-2026 GRAME | LGPL-2.1-or-later with the Faust exception (see below) |
| [Faust](https://github.com/grame-cncm/faust) compiler and architecture headers, used at build time only | 2002-2026 GRAME | LGPL-2.1-or-later with the Faust exception |
| WebCLAP port ([open-webclap](https://github.com/andremichelle/open-webclap) `ports/faust-aether`) | 2026 André Michelle | MIT |
| WASI shim ([open-webclap](https://github.com/andremichelle/open-webclap) `modules/webclap/wasi_shim.cpp`) | 2026 André Michelle | MIT |
| [CLAP](https://github.com/free-audio/clap) headers | 2014-2022 Alexandre Bique | MIT |

The Faust exception (https://github.com/grame-cncm/faust/blob/master-dev/COPYING) permits linking the generated
code and the standard libraries in proprietary and in MIT-licensed works; it is the license Faust itself ships the
libraries under.

## License text

> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
> documentation files (the "Software"), to deal in the Software without restriction, including without limitation
> the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
> and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all copies or substantial portions of
> the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
> THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
> TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.
